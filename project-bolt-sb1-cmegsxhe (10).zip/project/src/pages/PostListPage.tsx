import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAnalyticsContext } from '../contexts/AnalyticsContext';
import Header from '../components/Header';
import PostForm from '../components/PostForm';
import WelcomeScreen from '../components/WelcomeScreen';
import { usePosts } from '../hooks/usePosts';
import { PostFormData } from '../types';
import { Lightbulb, MessageCircle, Calendar, Trash2 } from 'lucide-react';
import { createSamplePost } from '../utils/sampleData';
import { hasSeenWelcome, markWelcomeAsSeen } from '../utils/storage';

const PostListPage: React.FC = () => {
  const { trackButton, trackEngagement } = useAnalyticsContext();
  const [currentView, setCurrentView] = useState<'all' | 'popular'>('all');
  const [showWelcome, setShowWelcome] = useState(!hasSeenWelcome());
  const [randomSeed, setRandomSeed] = useState(() => {
    // アプリ起動時のみ新しいランダムシードを生成
    return Math.random();
  });
  const {
    posts,
    loading,
    addPost,
    deletePost,
    canDeletePost,
    getPopularPosts
  } = usePosts();

  const handleAddPost = (data: PostFormData) => {
    addPost(data);
  };

  const handleWelcomeContinue = () => {
    trackButton('welcome_continue');
    trackEngagement('onboarding', 'welcome_screen_completed');
    markWelcomeAsSeen();
    setShowWelcome(false);
  };

  // Add sample post on first load if no posts exist
  React.useEffect(() => {
    if (!loading && posts.length === 0) {
      const samplePost = createSamplePost();
      addPost({
        title: samplePost.title,
        content: samplePost.content
      });
    }
  }, [loading, posts.length, addPost]);

  const displayPosts = currentView === 'popular' ? getPopularPosts() : posts;

  // すべての投稿カテゴリでランダム表示順序を適用
  const finalDisplayPosts = React.useMemo(() => {
    if (currentView === 'all') {
      // アプリ起動時に生成されたシードを使用してランダム化
      const shuffled = [...displayPosts];
      
      // シードベースの疑似ランダム関数
      let seed = randomSeed;
      const seededRandom = () => {
        seed = (seed * 9301 + 49297) % 233280;
        return seed / 233280;
      };
      
      // Fisher-Yates シャッフルアルゴリズム（シードベース）
      for (let i = shuffled.length - 1; i > 0; i--) {
        const j = Math.floor(seededRandom() * (i + 1));
        [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
      }
      return shuffled;
    }
    return displayPosts;
  }, [displayPosts, currentView, randomSeed]);

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('ja-JP', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-gray-400">読み込み中...</p>
        </div>
      </div>
    );
  }

  if (showWelcome) {
    return <WelcomeScreen onContinue={handleWelcomeContinue} />;
  }

  return (
    <div className="min-h-screen bg-gray-950">
      <Header currentView={currentView} onViewChange={setCurrentView} />
      
      {currentView === 'all' && <PostForm onSubmit={handleAddPost} />}
      
        <main className="max-w-5xl mx-auto px-4 pb-8">
        {currentView === 'popular' && (
          <div className="mb-6">
            <div className="flex items-center space-x-2 mb-4">
              <div className="p-2 bg-orange-600 rounded-lg">
                <Lightbulb className="h-5 w-5 text-white" />
              </div>
              <h2 className="text-xl font-bold text-white">Popular Ideas</h2>
            </div>
            <p className="text-gray-400 text-sm">
              Showing posts with the most comments
            </p>
          </div>
        )}
        
        {finalDisplayPosts.length === 0 ? (
          <div className="text-center py-16">
            <div className="p-6 bg-gray-800 rounded-xl border-2 border-dashed border-gray-600 max-w-md mx-auto">
              <Lightbulb className="h-12 w-12 text-gray-500 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-300 mb-2">
                {currentView === 'popular' ? 'No popular posts yet' : 'No posts yet'}
              </h3>
              <p className="text-gray-500 text-sm">
                {currentView === 'popular' 
                  ? 'Posts with many comments will appear here' 
                  : 'Try posting your first idea!'
                }
              </p>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            {finalDisplayPosts.map((post) => (
              <Link
                key={post.id} 
                to={`/post/${post.id}`}
                onClick={() => {
                  trackButton('view_post_detail');
                  trackEngagement('content', 'post_click', 1);
                }}
                className="block bg-gray-800 rounded-xl border border-gray-700 overflow-hidden transition-all duration-200 hover:border-gray-600 hover:shadow-lg hover:scale-[1.01]"
              >
                <article className="p-8">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1 min-w-0">
                      <h3 className="text-xl md:text-2xl font-bold text-white mb-3 leading-tight break-words">
                        {post.title}
                      </h3>
                      <div className="flex items-center text-sm text-gray-400 mb-3">
                        <div className="flex items-center space-x-1">
                          <Calendar className="h-4 w-4" />
                          <span>{formatDate(post.createdAt)}</span>
                        </div>
                      </div>
                    </div>
                    
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex-1"></div>
                    <div className="flex items-center space-x-4">
                      <button
                        onClick={(e) => {
                          e.preventDefault();
                          // コメント機能は詳細ページで実装
                        }}
                        className="flex items-center space-x-2 px-3 py-2 text-gray-400 hover:text-blue-400 hover:bg-gray-700 rounded-lg transition-colors group"
                      >
                        <MessageCircle className="h-4 w-4 group-hover:scale-110 transition-transform" />
                        <span>{post.commentCount} comments</span>
                      </button>
                    </div>
                  </div>
                </article>
              </Link>
            ))}
          </div>
        )}
      </main>
    </div>
  );
};

export default PostListPage;