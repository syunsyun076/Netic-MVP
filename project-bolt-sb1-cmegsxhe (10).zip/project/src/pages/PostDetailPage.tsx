import React from 'react';
import { useParams, Link, Navigate } from 'react-router-dom';
import { ArrowLeft, Calendar, MessageCircle, Trash2 } from 'lucide-react';
import { useAnalyticsContext } from '../contexts/AnalyticsContext';
import { usePosts } from '../hooks/usePosts';
import CommentForm from '../components/CommentForm';
import CommentList from '../components/CommentList';

const PostDetailPage: React.FC = () => {
  const { trackButton, trackEngagement } = useAnalyticsContext();
  const { id } = useParams<{ id: string }>();
  const {
    posts,
    loading,
    deletePost,
    addComment,
    deleteComment,
    canDeletePost,
    canDeleteComment,
    getCommentsForPost
  } = usePosts();

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-gray-400">Loading...</p>
        </div>
      </div>
    );
  }

  const post = posts.find(p => p.id === id);

  if (!post) {
    return <Navigate to="/" replace />;
  }

  const comments = getCommentsForPost(post.id);

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('ja-JP', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      weekday: 'long'
    }).format(date);
  };

  const handleAddComment = (content: string) => {
    trackEngagement('content', 'comment_added', 1);
    addComment(post.id, content);
  };

  const handleDeletePost = () => {
    const deleted = deletePost(post.id);
    if (deleted) {
      // Navigate back to home after deletion
      window.location.href = '/';
    }
  };

  return (
    <div className="min-h-screen bg-gray-950">
      {/* Header */}
      <header className="bg-gray-900 border-b border-gray-800 sticky top-0 z-10">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link 
              to="/"
             onClick={() => {
               trackButton('back_to_post_list');
               trackEngagement('navigation', 'back_button');
             }}
              className="flex items-center space-x-2 text-gray-400 hover:text-white transition-colors group"
            >
              <ArrowLeft className="h-5 w-5 group-hover:-translate-x-1 transition-transform" />
              <span>Back to posts</span>
            </Link>
            
            <div className="flex items-center space-x-3">
              <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent tracking-tight">
                Netic
              </h1>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-8">
        <div className="max-w-3xl mx-auto">
          {/* タイトルセクション */}
          <div className="mb-8 pt-4">
            {/* 投稿者情報 */}
            <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
              <div className="flex items-center space-x-4 text-sm text-gray-400">
                <div className="flex items-center space-x-1">
                  <Calendar className="h-4 w-4" />
                  <span>{formatDate(post.createdAt)}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <MessageCircle className="h-4 w-4" />
                  <span>{post.commentCount} comments</span>
                 </div>
               </div>
             </div>
          </div>

          {/* メインコンテンツ */}
          <article className="bg-gray-800 rounded-xl border border-gray-700 overflow-hidden mb-8 transition-all duration-200 hover:border-gray-600 hover:shadow-lg">
            <div className="p-6 md:p-8">
              <div className="text-gray-300 leading-relaxed whitespace-pre-wrap break-words overflow-wrap-anywhere">
                {post.content}
              </div>
            </div>
          </article>

          {/* コメントセクション */}
          <section className="bg-gray-800 rounded-xl border border-gray-700 overflow-hidden">
            <div className="p-6 border-b border-gray-700">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                  <MessageCircle className="h-5 w-5 text-white" />
                </div>
                <h2 className="text-xl font-semibold text-white">Comments ({comments.length})</h2>
              </div>
              <CommentForm onSubmit={handleAddComment} />
            </div>
            
            <div className="p-6">
              {comments.length > 0 ? (
                <CommentList 
                  comments={comments} 
                  onDelete={deleteComment}
                  canDelete={canDeleteComment}
                />
              ) : (
                <div className="text-center py-16">
                  <div className="w-16 h-16 bg-gray-700 rounded-full flex items-center justify-center mx-auto mb-4">
                    <MessageCircle className="h-8 w-8 text-gray-500" />
                  </div>
                  <h3 className="text-lg font-medium text-gray-400 mb-2">No comments yet</h3>
                  <p className="text-gray-500">Be the first to post a comment!</p>
                </div>
              )}
            </div>
          </section>
        </div>
      </main>
    </div>
  );
};

export default PostDetailPage;