import { useState, useEffect, useCallback } from 'react';
import { Post, Comment, PostFormData, CommentFormData } from '../types';
import { loadPosts, savePosts, loadComments, saveComments, generateId, getCurrentUserId } from '../utils/storage';

export const usePosts = () => {
  const [posts, setPosts] = useState<Post[]>([]);
  const [comments, setComments] = useState<Comment[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadedPosts = loadPosts();
    const loadedComments = loadComments();
    
    // Update comment counts
    const postsWithCounts = loadedPosts.map(post => ({
      ...post,
      commentCount: loadedComments.filter(comment => comment.postId === post.id).length
    }));
    
    setPosts(postsWithCounts);
    setComments(loadedComments);
    setLoading(false);
  }, []);

  const addPost = useCallback((postData: PostFormData) => {
    const newPost: Post = {
      id: generateId(),
      title: postData.title,
      content: postData.content,
      authorId: getCurrentUserId(),
      createdAt: new Date(),
      commentCount: 0
    };

    const updatedPosts = [newPost, ...posts];
    setPosts(updatedPosts);
    savePosts(updatedPosts);
  }, [posts]);

  const deletePost = useCallback((postId: string) => {
    // 削除機能は無効化されています
    console.warn('Post deletion feature is disabled');
    return false;
  }, [posts, comments]);

  const addComment = useCallback((postId: string, content: string) => {
    const newComment: Comment = {
      id: generateId(),
      postId,
      content,
      authorId: getCurrentUserId(),
      createdAt: new Date()
    };

    const updatedComments = [newComment, ...comments];
    const updatedPosts = posts.map(post => 
      post.id === postId 
        ? { ...post, commentCount: post.commentCount + 1 }
        : post
    );

    setComments(updatedComments);
    setPosts(updatedPosts);
    saveComments(updatedComments);
    savePosts(updatedPosts);
  }, [comments, posts]);

  const deleteComment = useCallback((commentId: string) => {
    // 削除機能は無効化されています
    console.warn('Comment deletion feature is disabled');
    return false;
  }, [comments, posts]);

  const canDeletePost = useCallback((post: Post) => {
    return post.authorId === getCurrentUserId();
  }, []);

  const canDeleteComment = useCallback((comment: Comment) => {
    return comment.authorId === getCurrentUserId();
  }, []);

  const getCommentsForPost = useCallback((postId: string) => {
    return comments.filter(comment => comment.postId === postId);
  }, [comments]);

  const getPopularPosts = useCallback(() => {
    return [...posts].sort((a, b) => b.commentCount - a.commentCount).slice(0, 5);
  }, [posts]);

  return {
    posts,
    comments,
    loading,
    addPost,
    deletePost,
    addComment,
    deleteComment,
    canDeletePost,
    canDeleteComment,
    getCommentsForPost,
    getPopularPosts
  };
};