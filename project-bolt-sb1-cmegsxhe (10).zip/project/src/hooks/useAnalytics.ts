import { useEffect, useCallback } from 'react';
import { useLocation } from 'react-router-dom';
import { 
  trackPageView, 
  trackEvent, 
  trackButtonClick, 
  trackFormSubmission,
  trackExternalLink,
  trackDownload,
  trackEngagement 
} from '../utils/analytics';

/**
 * Custom hook for Google Analytics 4 tracking
 * Provides easy-to-use tracking functions and automatic page view tracking
 */
export const useAnalytics = () => {
  const location = useLocation();

  // Track page views on route changes
  useEffect(() => {
    trackPageView({
      page_path: location.pathname,
      page_location: window.location.href,
      page_title: document.title,
    });
  }, [location]);

  // Memoized tracking functions
  const analytics = {
    // Page tracking
    trackPage: useCallback((pageData?: { title?: string; path?: string }) => {
      trackPageView({
        page_title: pageData?.title || document.title,
        page_path: pageData?.path || location.pathname,
        page_location: window.location.href,
      });
    }, [location.pathname]),

    // Event tracking
    trackEvent: useCallback((eventName: string, parameters?: Record<string, any>) => {
      trackEvent(eventName, parameters);
    }, []),

    // Button tracking
    trackButton: useCallback((buttonName: string, additionalData?: Record<string, any>) => {
      trackButtonClick(buttonName, additionalData);
    }, []),

    // Form tracking
    trackForm: useCallback((formName: string, success: boolean = true, additionalData?: Record<string, any>) => {
      trackFormSubmission(formName, success, additionalData);
    }, []),

    // Link tracking
    trackExternalLink: useCallback((url: string, linkText?: string) => {
      trackExternalLink(url, linkText);
    }, []),

    // Download tracking
    trackDownload: useCallback((fileName: string, fileType?: string) => {
      trackDownload(fileName, fileType);
    }, []),

    // Engagement tracking
    trackEngagement: useCallback((action: string, target?: string, value?: number) => {
      trackEngagement(action, target, value);
    }, []),
  };

  return analytics;
};