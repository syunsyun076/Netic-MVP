import { GAEvent, GAPageView, GAConfig } from '../types/analytics';

// GA4 Configuration
const GA4_MEASUREMENT_ID = import.meta.env.VITE_GA4_MEASUREMENT_ID;
const IS_PRODUCTION = import.meta.env.VITE_NODE_ENV === 'production';
const IS_DEVELOPMENT = import.meta.env.VITE_NODE_ENV === 'development';

/**
 * Initialize Google Analytics 4
 * Loads gtag.js script and configures GA4 with the measurement ID
 */
export const initializeGA4 = (): void => {
  // Skip initialization in development or if measurement ID is missing
  if (!IS_PRODUCTION || !GA4_MEASUREMENT_ID) {
    if (IS_DEVELOPMENT) {
      console.log('GA4: Skipping initialization in development environment');
    }
    return;
  }

  try {
    // Initialize dataLayer if it doesn't exist
    window.dataLayer = window.dataLayer || [];
    
    // Define gtag function
    window.gtag = function() {
      window.dataLayer.push(arguments);
    };

    // Set timestamp
    window.gtag('js', new Date());

    // Configure GA4
    window.gtag('config', GA4_MEASUREMENT_ID, {
      page_title: document.title,
      page_location: window.location.href,
      send_page_view: true,
    });

    // Load gtag.js script asynchronously
    const script = document.createElement('script');
    script.async = true;
    script.src = `https://www.googletagmanager.com/gtag/js?id=${GA4_MEASUREMENT_ID}`;
    document.head.appendChild(script);

    if (IS_DEVELOPMENT) {
      console.log('GA4: Initialized successfully with ID:', GA4_MEASUREMENT_ID);
    }
  } catch (error) {
    console.error('GA4: Failed to initialize:', error);
  }
};

/**
 * Track page views for SPA navigation
 * Should be called on route changes
 */
export const trackPageView = (pageData?: Partial<GAPageView>): void => {
  if (!IS_PRODUCTION || !GA4_MEASUREMENT_ID || typeof window.gtag !== 'function') {
    if (IS_DEVELOPMENT) {
      console.log('GA4: Page view tracked (dev mode):', {
        page_title: pageData?.page_title || document.title,
        page_location: pageData?.page_location || window.location.href,
        page_path: pageData?.page_path || window.location.pathname,
      });
    }
    return;
  }

  try {
    const pageViewData: GAPageView = {
      page_title: pageData?.page_title || document.title,
      page_location: pageData?.page_location || window.location.href,
      page_path: pageData?.page_path || window.location.pathname,
    };

    window.gtag('config', GA4_MEASUREMENT_ID, pageViewData);

    if (IS_DEVELOPMENT) {
      console.log('GA4: Page view tracked:', pageViewData);
    }
  } catch (error) {
    console.error('GA4: Failed to track page view:', error);
  }
};

/**
 * Track custom events
 * @param eventName - Name of the event
 * @param parameters - Event parameters
 */
export const trackEvent = (eventName: string, parameters?: Record<string, any>): void => {
  if (!IS_PRODUCTION || !GA4_MEASUREMENT_ID || typeof window.gtag !== 'function') {
    if (IS_DEVELOPMENT) {
      console.log('GA4: Event tracked (dev mode):', eventName, parameters);
    }
    return;
  }

  try {
    window.gtag('event', eventName, parameters || {});

    if (IS_DEVELOPMENT) {
      console.log('GA4: Event tracked:', eventName, parameters);
    }
  } catch (error) {
    console.error('GA4: Failed to track event:', error);
  }
};

/**
 * Track button clicks
 * @param buttonName - Identifier for the button
 * @param additionalData - Additional tracking data
 */
export const trackButtonClick = (buttonName: string, additionalData?: Record<string, any>): void => {
  trackEvent('button_click', {
    button_name: buttonName,
    event_category: 'engagement',
    ...additionalData,
  });
};

/**
 * Track form submissions
 * @param formName - Name/identifier of the form
 * @param success - Whether the submission was successful
 * @param additionalData - Additional tracking data
 */
export const trackFormSubmission = (
  formName: string, 
  success: boolean = true, 
  additionalData?: Record<string, any>
): void => {
  trackEvent('form_submit', {
    form_name: formName,
    success: success,
    event_category: 'engagement',
    ...additionalData,
  });
};

/**
 * Track external link clicks
 * @param url - The external URL being clicked
 * @param linkText - Text of the link
 */
export const trackExternalLink = (url: string, linkText?: string): void => {
  trackEvent('click', {
    event_category: 'outbound',
    event_label: url,
    link_text: linkText,
    link_url: url,
  });
};

/**
 * Track file downloads
 * @param fileName - Name of the downloaded file
 * @param fileType - Type/extension of the file
 */
export const trackDownload = (fileName: string, fileType?: string): void => {
  trackEvent('file_download', {
    file_name: fileName,
    file_type: fileType,
    event_category: 'engagement',
  });
};

/**
 * Track user engagement events
 * @param action - The action performed
 * @param target - Target of the action
 * @param value - Numeric value associated with the action
 */
export const trackEngagement = (action: string, target?: string, value?: number): void => {
  trackEvent('engagement', {
    engagement_action: action,
    engagement_target: target,
    value: value,
    event_category: 'user_engagement',
  });
};