import { Post } from '../types';
import { generateId, getCurrentUserId } from './storage';

export const createSamplePost = (): Post => {
  return {
    id: generateId(),
    title: 'Amazing Tech Innovation Ideas! 🚀💡',
    content: `Here are some exciting technology concepts that could change the world:

1. Smart Home Automation 🏠
   - Voice-controlled everything
   - Energy-efficient systems
   - Security & convenience combined

2. AI-Powered Learning Platform 🤖📚
   - Personalized education paths
   - Real-time progress tracking
   - Interactive content delivery

3. Sustainable Transportation 🌱🚗
   - Electric vehicle networks
   - Smart traffic management
   - Eco-friendly solutions

What do you think? Share your thoughts! 💭✨

#Innovation #Technology #Future #Ideas`,
    authorId: getCurrentUserId(),
    createdAt: new Date(),
    commentCount: 0
  };
};