import { Post, Comment } from '../types';

const POSTS_STORAGE_KEY = 'idea_platform_posts';
const COMMENTS_STORAGE_KEY = 'idea_platform_comments';

export const loadPosts = (): Post[] => {
  try {
    const data = localStorage.getItem(POSTS_STORAGE_KEY);
    if (!data) return [];
    
    const posts = JSON.parse(data);
    return posts.map((post: any) => ({
      ...post,
      createdAt: new Date(post.createdAt)
    }));
  } catch {
    return [];
  }
};

export const savePosts = (posts: Post[]): void => {
  try {
    localStorage.setItem(POSTS_STORAGE_KEY, JSON.stringify(posts));
  } catch (error) {
    console.error('Failed to save posts:', error);
  }
};

export const loadComments = (): Comment[] => {
  try {
    const data = localStorage.getItem(COMMENTS_STORAGE_KEY);
    if (!data) return [];
    
    const comments = JSON.parse(data);
    return comments.map((comment: any) => ({
      ...comment,
      createdAt: new Date(comment.createdAt)
    }));
  } catch {
    return [];
  }
};

export const saveComments = (comments: Comment[]): void => {
  try {
    localStorage.setItem(COMMENTS_STORAGE_KEY, JSON.stringify(comments));
  } catch (error) {
    console.error('Failed to save comments:', error);
  }
};

export const generateId = (): string => {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
};

export const getCurrentUserId = (): string => {
  let userId = localStorage.getItem('current_user_id');
  if (!userId) {
    userId = generateId();
    localStorage.setItem('current_user_id', userId);
  }
  return userId;
};

export const hasSeenWelcome = (): boolean => {
  return localStorage.getItem('has_seen_welcome') === 'true';
};

export const markWelcomeAsSeen = (): void => {
  localStorage.setItem('has_seen_welcome', 'true');
};