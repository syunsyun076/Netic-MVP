// GA4 TypeScript type definitions
export interface GAEvent {
  action: string;
  category?: string;
  label?: string;
  value?: number;
  custom_parameters?: Record<string, any>;
}

export interface GAPageView {
  page_title: string;
  page_location: string;
  page_path: string;
}

export interface GAConfig {
  page_title?: string;
  page_location?: string;
  custom_map?: Record<string, string>;
  send_page_view?: boolean;
}

// Extend Window interface for gtag
declare global {
  interface Window {
    gtag: (
      command: 'config' | 'event' | 'js' | 'set',
      targetId: string | Date | Record<string, any>,
      config?: GAConfig | GAEvent
    ) => void;
    dataLayer: any[];
  }
}