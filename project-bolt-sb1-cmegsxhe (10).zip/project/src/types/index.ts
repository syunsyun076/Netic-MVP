export interface Post {
  id: string;
  title: string;
  content: string;
  createdAt: Date;
  authorId: string;
  commentCount: number;
}

export interface Comment {
  id: string;
  postId: string;
  content: string;
  authorId: string;
  createdAt: Date;
}

export interface PostFormData {
  title: string;
  content: string;
}

export interface CommentFormData {
  content: string;
}