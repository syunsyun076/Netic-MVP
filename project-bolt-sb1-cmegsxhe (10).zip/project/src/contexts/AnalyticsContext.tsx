import React, { createContext, useContext, useEffect, ReactNode } from 'react';
import { initializeGA4 } from '../utils/analytics';
import { useAnalytics } from '../hooks/useAnalytics';

// Analytics context type
interface AnalyticsContextType {
  trackPage: (pageData?: { title?: string; path?: string }) => void;
  trackEvent: (eventName: string, parameters?: Record<string, any>) => void;
  trackButton: (buttonName: string, additionalData?: Record<string, any>) => void;
  trackForm: (formName: string, success?: boolean, additionalData?: Record<string, any>) => void;
  trackExternalLink: (url: string, linkText?: string) => void;
  trackDownload: (fileName: string, fileType?: string) => void;
  trackEngagement: (action: string, target?: string, value?: number) => void;
}

// Create context
const AnalyticsContext = createContext<AnalyticsContextType | undefined>(undefined);

// Provider props
interface AnalyticsProviderProps {
  children: ReactNode;
}

/**
 * Analytics Provider Component
 * Initializes GA4 and provides tracking functions to child components
 */
export const AnalyticsProvider: React.FC<AnalyticsProviderProps> = ({ children }) => {
  const analytics = useAnalytics();

  // Initialize GA4 on mount
  useEffect(() => {
    initializeGA4();
  }, []);

  return (
    <AnalyticsContext.Provider value={analytics}>
      {children}
    </AnalyticsContext.Provider>
  );
};

/**
 * Hook to use analytics context
 * Throws error if used outside of AnalyticsProvider
 */
export const useAnalyticsContext = (): AnalyticsContextType => {
  const context = useContext(AnalyticsContext);
  
  if (context === undefined) {
    throw new Error('useAnalyticsContext must be used within an AnalyticsProvider');
  }
  
  return context;
};