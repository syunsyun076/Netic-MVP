import React, { useState } from 'react';
import { MessageCircle, Trash2, User, Calendar } from 'lucide-react';
import { Post } from '../types';
import CommentForm from './CommentForm';
import CommentList from './CommentList';

interface PostCardProps {
  post: Post;
  onDelete: (postId: string) => void;
  canDelete: boolean;
  onAddComment: (postId: string, content: string, author: string) => void;
  onDeleteComment: (commentId: string) => void;
  canDeleteComment: (comment: any) => boolean;
  comments: Array<{
    id: string;
    content: string;
    author: string;
    createdAt: Date;
  }>;
}

const PostCard: React.FC<PostCardProps> = ({ 
  post, 
  onDelete, 
  canDelete,
  onAddComment, 
  onDeleteComment, 
  canDeleteComment,
  comments 
}) => {
  const [showComments, setShowComments] = useState(false);

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('ja-JP', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  return (
    <article className="bg-gray-800 rounded-xl border border-gray-700 overflow-hidden transition-all duration-200 hover:border-gray-600 hover:shadow-lg">
      <div className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1 min-w-0">
            <h3 className="text-xl font-semibold text-white mb-2 line-clamp-2">
              {post.title}
            </h3>
            <div className="flex items-center space-x-4 text-sm text-gray-400 mb-3">
              <div className="flex items-center space-x-1">
                <User className="h-4 w-4" />
                <span>{post.author}</span>
              </div>
              <div className="flex items-center space-x-1">
                <Calendar className="h-4 w-4" />
                <span>{formatDate(post.createdAt)}</span>
              </div>
            </div>
          </div>
          
          <button
            onClick={() => {
              const deleted = onDelete(post.id);
              if (deleted) {
                // UIフィードバック: 削除成功を示すための短時間の視覚効果
                const button = event?.currentTarget;
                if (button) {
                  button.style.backgroundColor = '#10b981';
                  button.style.color = 'white';
                  setTimeout(() => {
                    button.style.backgroundColor = '';
                    button.style.color = '';
                  }, 500);
                }
              }
            }}
            className={`p-2 rounded-lg transition-colors ml-4 flex-shrink-0 ${
              canDelete
                ? 'text-gray-400 hover:text-red-400 hover:bg-gray-700 cursor-pointer'
                : 'text-gray-600 cursor-not-allowed opacity-50'
            }`}
            title="Delete post"
            disabled={!canDelete}
          >
            <Trash2 className="h-4 w-4" />
          </button>
        </div>
        
        <p className="text-gray-300 leading-relaxed mb-4 whitespace-pre-wrap">
          {post.content}
        </p>
        
        <div className="flex items-center justify-between">
          <button
            onClick={() => setShowComments(!showComments)}
            className="flex items-center space-x-2 px-3 py-2 text-gray-400 hover:text-blue-400 hover:bg-gray-700 rounded-lg transition-colors group"
          >
            <MessageCircle className="h-4 w-4 group-hover:scale-110 transition-transform" />
            <span>{post.commentCount} comments</span>
          </button>
        </div>
      </div>
      
      {showComments && (
        <div className="border-t border-gray-700 bg-gray-850">
          <div className="p-6">
            <CommentForm 
              onSubmit={(content, author) => onAddComment(post.id, content, author)}
            />
            
            {comments.length > 0 && (
              <div className="mt-6">
                <CommentList 
                  comments={comments} 
                  onDelete={onDeleteComment}
                  canDelete={canDeleteComment}
                />
              </div>
            )}
          </div>
        </div>
      )}
    </article>
  );
};

export default PostCard;