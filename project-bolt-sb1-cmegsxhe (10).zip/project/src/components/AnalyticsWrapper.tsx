import React, { ReactNode } from 'react';
import { AnalyticsProvider } from '../contexts/AnalyticsContext';

interface AnalyticsWrapperProps {
  children: ReactNode;
}

/**
 * Analytics Wrapper Component
 * Higher-order component that wraps the application with analytics functionality
 */
export const AnalyticsWrapper: React.FC<AnalyticsWrapperProps> = ({ children }) => {
  return (
    <AnalyticsProvider>
      {children}
    </AnalyticsProvider>
  );
};