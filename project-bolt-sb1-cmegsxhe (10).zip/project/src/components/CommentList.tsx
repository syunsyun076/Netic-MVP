import React from 'react';
import { useState } from 'react';
import { Trash2, User, Calendar } from 'lucide-react';

interface Comment {
  id: string;
  content: string;
  authorId?: string;
  createdAt: Date;
}

interface CommentListProps {
  comments: Comment[];
  onDelete: (commentId: string) => void;
  canDelete: (comment: Comment) => boolean;
}

const ExpandableText: React.FC<{ text: string }> = ({ text }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const PREVIEW_LENGTH = 100;
  
  if (text.length <= PREVIEW_LENGTH) {
    return (
      <span className="text-gray-300 text-sm leading-relaxed whitespace-pre-wrap break-words overflow-wrap-anywhere">
        {text}
      </span>
    );
  }
  
  return (
    <div className="text-gray-300 text-sm leading-relaxed break-words overflow-wrap-anywhere">
      <span className="whitespace-pre-wrap">
        {isExpanded ? text : `${text.slice(0, PREVIEW_LENGTH)}`}
      </span>
      {!isExpanded && (
        <>
          <span className="text-gray-500">...</span>
          <button
            onClick={() => setIsExpanded(true)}
            className="ml-2 text-blue-400 hover:text-blue-300 text-xs font-medium transition-colors inline-flex items-center"
          >
            Show more
          </button>
        </>
      )}
      {isExpanded && (
        <button
          onClick={() => setIsExpanded(false)}
          className="ml-2 text-gray-400 hover:text-gray-300 text-xs font-medium transition-colors inline-flex items-center"
        >
          Show less
        </button>
      )}
    </div>
  );
};

const CommentList: React.FC<CommentListProps> = ({ comments, onDelete, canDelete }) => {
  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('ja-JP', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  if (comments.length === 0) {
    return (
      <div className="text-center py-8 text-gray-500">
        No comments yet
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h4 className="text-sm font-medium text-gray-400 border-b border-gray-700 pb-2">
        Comments ({comments.length})
      </h4>
      
      {comments.map((comment) => (
        <div 
          key={comment.id} 
          className="bg-gray-900 rounded-lg p-4 border border-gray-700"
        >
          <div className="flex items-start justify-between mb-2">
            <div className="flex items-center text-sm text-gray-400">
              <div className="flex items-center space-x-1">
                <Calendar className="h-3 w-3" />
                <span>{formatDate(comment.createdAt)}</span>
              </div>
            </div>
          </div>
          
          <ExpandableText text={comment.content} />
        </div>
      ))}
    </div>
  );
};

export default CommentList;