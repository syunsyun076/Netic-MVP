import React from 'react';
import { TrendingUp } from 'lucide-react';
import { useAnalyticsContext } from '../contexts/AnalyticsContext';

interface HeaderProps {
  currentView: 'all' | 'popular';
  onViewChange: (view: 'all' | 'popular') => void;
}

const Header: React.FC<HeaderProps> = ({ currentView, onViewChange }) => {
  const { trackButton, trackEngagement } = useAnalyticsContext();

  return (
    <header className="bg-gray-900 border-b border-gray-800 sticky top-0 z-10">
      <div className="max-w-4xl mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => {
                  trackButton('scroll_to_top');
                  trackEngagement('scroll', 'header_logo');
                  window.scrollTo({
                    top: 0,
                    left: 0,
                    behavior: 'smooth'
                  });
                }}
                className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent tracking-tight hover:scale-105 transition-transform duration-200 cursor-pointer focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50 rounded-lg px-2 py-1"
                title="ページの最上部へ戻る"
              >
                Netic
              </button>
            </div>
          </div>
          
          <nav className="flex space-x-1">
            <button
              onClick={() => {
                onViewChange('all');
                trackButton('view_all_posts');
                trackEngagement('navigation', 'all_posts');
              }}
              className={`px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
                currentView === 'all'
                  ? 'bg-blue-600 text-white shadow-lg'
                  : 'text-gray-400 hover:text-white hover:bg-gray-800'
              }`}
            >
              All Posts
            </button>
            <button
              onClick={() => {
                onViewChange('popular');
                trackButton('view_popular_posts');
                trackEngagement('navigation', 'popular_posts');
              }}
              className={`px-4 py-2 rounded-lg font-medium transition-all duration-200 flex items-center space-x-2 ${
                currentView === 'popular'
                  ? 'bg-orange-600 text-white shadow-lg'
                  : 'text-gray-400 hover:text-white hover:bg-gray-800'
              }`}
            >
              <TrendingUp className="h-4 w-4" />
              <span>Popular Posts</span>
            </button>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;