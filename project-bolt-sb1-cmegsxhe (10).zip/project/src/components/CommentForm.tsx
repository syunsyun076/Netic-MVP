import React, { useState } from 'react';
import { Send } from 'lucide-react';
import { useAnalyticsContext } from '../contexts/AnalyticsContext';

interface CommentFormProps {
  onSubmit: (content: string) => void;
}

const CommentForm: React.FC<CommentFormProps> = ({ onSubmit }) => {
  const { trackForm } = useAnalyticsContext();
  const [content, setContent] = useState('');
  
  const MAX_LENGTH = 280;
  const remainingChars = MAX_LENGTH - content.length;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim()) return;
    
    try {
      onSubmit(content.trim());
      trackForm('comment_submission', true, {
        content_length: content.trim().length,
      });
      setContent('');
    } catch (error) {
      trackForm('comment_submission', false, {
        error: 'submission_failed',
      });
    }
  };

  const handleContentChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const value = e.target.value;
    if (value.length <= MAX_LENGTH) {
      setContent(value);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-3">
      <div>
        <div className="flex justify-between items-center mb-2">
          <span className={`text-xs ${
            remainingChars < 20 
              ? remainingChars < 0 
                ? 'text-red-400' 
                : 'text-yellow-400'
              : 'text-gray-500'
          }`}>
            <span>Send</span>
          </span>
        </div>
        <textarea
          placeholder="Enter your comment"
          value={content}
          onChange={handleContentChange}
          rows={3}
          className={`w-full px-4 py-3 bg-gray-900 border rounded-lg text-white placeholder-gray-400 focus:ring-1 outline-none transition-colors resize-none ${
            remainingChars >= 0
              ? 'border-gray-600 focus:border-blue-500 focus:ring-blue-500'
              : 'border-red-500 focus:border-red-500 focus:ring-red-500'
          }`}
          maxLength={MAX_LENGTH}
          required
        />
      </div>
      
      <div className="flex justify-end">
        <button
          type="submit"
          disabled={content.trim().length === 0 || remainingChars < 0}
          className={`px-4 py-2 rounded-lg font-medium flex items-center space-x-2 text-sm transition-colors ${
            content.trim().length > 0 && remainingChars >= 0
              ? 'bg-blue-600 text-white hover:bg-blue-700 cursor-pointer'
              : 'bg-gray-600 text-gray-400 cursor-not-allowed'
          }`}
        >
          <Send className="h-4 w-4" />
          <span>送信</span>
        </button>
      </div>
    </form>
  );
};

export default CommentForm;