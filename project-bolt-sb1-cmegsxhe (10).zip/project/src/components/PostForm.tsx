import React, { useState } from 'react';
import { Plus, X } from 'lucide-react';
import { PostFormData } from '../types';
import { useAnalyticsContext } from '../contexts/AnalyticsContext';

interface PostFormProps {
  onSubmit: (data: PostFormData) => void;
}

const PostForm: React.FC<PostFormProps> = ({ onSubmit }) => {
  const { trackButton, trackForm } = useAnalyticsContext();
  const [isOpen, setIsOpen] = useState(false);
  const [formData, setFormData] = useState<PostFormData>({
    title: '',
    content: ''
  });

  const TITLE_MAX_LENGTH = 50;
  const CONTENT_MAX_LENGTH = 500;
  const TITLE_MIN_LENGTH = 1;
  const CONTENT_MIN_LENGTH = 1;

  const titleLength = formData.title.length;
  const contentLength = formData.content.length;
  const isTitleValid = titleLength >= TITLE_MIN_LENGTH && titleLength <= TITLE_MAX_LENGTH;
  const isContentValid = contentLength >= CONTENT_MIN_LENGTH && contentLength <= CONTENT_MAX_LENGTH;
  const isFormValid = isTitleValid && isContentValid && formData.title.trim() && formData.content.trim();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isFormValid) return;
    
    try {
      onSubmit(formData);
      trackForm('post_creation', true, {
        title_length: formData.title.length,
        content_length: formData.content.length,
      });
      setFormData({ title: '', content: '' });
      setIsOpen(false);
    } catch (error) {
      trackForm('post_creation', false, {
        error: 'submission_failed',
      });
    }
  };

  const handleTitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    if (value.length <= TITLE_MAX_LENGTH) {
      setFormData(prev => ({ ...prev, title: value }));
    }
  };

  const handleContentChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const value = e.target.value;
    if (value.length <= CONTENT_MAX_LENGTH) {
      setFormData(prev => ({ ...prev, content: value }));
    }
  };
  if (!isOpen) {
    return (
      <button
        onClick={() => {
          setIsOpen(true);
          trackButton('open_post_form');
        }}
        className="fixed bottom-6 right-6 w-16 h-16 bg-blue-600 hover:bg-blue-700 rounded-full flex items-center justify-center text-white shadow-lg hover:shadow-xl transition-all duration-200 group active:scale-95 hover:scale-105 z-50"
        title="Post a new idea"
      >
        <Plus className="h-8 w-8 group-hover:rotate-90 transition-transform duration-200" />
      </button>
    );
  }

  return (
    <>
      {/* Overlay */}
      <div 
        className="fixed inset-0 bg-black bg-opacity-50 z-40"
        onClick={() => setIsOpen(false)}
      />
      
      {/* Form Modal */}
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <form onSubmit={handleSubmit} className="bg-gray-800 rounded-xl p-6 border border-gray-700 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-white">New Idea</h2>
          <button
            type="button"
            onClick={() => {
              setIsOpen(false);
              trackButton('close_post_form');
            }}
            className="p-1 text-gray-400 hover:text-white hover:bg-gray-700 rounded-lg transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
        
        <div className="space-y-4">
          <div>
            <div className="flex justify-between items-center mb-2">
              <label className="text-sm font-medium text-gray-300">Title</label>
              <span className={`text-xs ${
                titleLength > TITLE_MAX_LENGTH * 0.8 
                  ? titleLength >= TITLE_MAX_LENGTH 
                    ? 'text-red-400' 
                    : 'text-yellow-400'
                  : 'text-gray-500'
              }`}>
                {titleLength}/{TITLE_MAX_LENGTH}
              </span>
            </div>
            <input
              type="text"
              placeholder="Enter title"
              value={formData.title}
              onChange={handleTitleChange}
              className={`w-full px-4 py-3 bg-gray-900 border rounded-lg text-white placeholder-gray-400 focus:ring-1 outline-none transition-colors ${
                isTitleValid 
                  ? 'border-gray-600 focus:border-blue-500 focus:ring-blue-500' 
                  : 'border-red-500 focus:border-red-500 focus:ring-red-500'
              }`}
              maxLength={TITLE_MAX_LENGTH}
              required
            />
            {!isTitleValid && titleLength > 0 && (
              <p className="text-red-400 text-xs mt-1">
                Title must be between {TITLE_MIN_LENGTH} and {TITLE_MAX_LENGTH} characters
              </p>
            )}
          </div>
          
          <div>
            <div className="flex justify-between items-center mb-2">
              <label className="text-sm font-medium text-gray-300">Content</label>
              <span className={`text-xs ${
                contentLength > CONTENT_MAX_LENGTH * 0.8 
                  ? contentLength >= CONTENT_MAX_LENGTH 
                    ? 'text-red-400' 
                    : 'text-yellow-400'
                  : 'text-gray-500'
              }`}>
                {contentLength}/{CONTENT_MAX_LENGTH}
              </span>
            </div>
            <textarea
              placeholder="Enter idea details"
              value={formData.content}
              onChange={handleContentChange}
              rows={4}
              className={`w-full px-4 py-3 bg-gray-900 border rounded-lg text-white placeholder-gray-400 focus:ring-1 outline-none transition-colors resize-none ${
                isContentValid 
                  ? 'border-gray-600 focus:border-blue-500 focus:ring-blue-500' 
                  : 'border-red-500 focus:border-red-500 focus:ring-red-500'
              }`}
              maxLength={CONTENT_MAX_LENGTH}
              required
            />
            {!isContentValid && contentLength > 0 && (
              <p className="text-red-400 text-xs mt-1">
                Content must be between {CONTENT_MIN_LENGTH} and {CONTENT_MAX_LENGTH} characters
              </p>
            )}
          </div>
        </div>
        
        <div className="flex justify-end space-x-3 mt-6">
          <button
            type="button"
            onClick={() => {
              setIsOpen(false);
              trackButton('cancel_post_form');
            }}
            className="px-4 py-2 text-gray-400 hover:text-white transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={!isFormValid}
            className={`px-6 py-2 rounded-lg font-medium transition-colors ${
              isFormValid
                ? 'bg-blue-600 text-white hover:bg-blue-700 cursor-pointer'
                : 'bg-gray-600 text-gray-400 cursor-not-allowed'
            }`}
          >
            Post
          </button>
        </div>
      </form>
      </div>
    </>
  );
};

export default PostForm;