import React from 'react';
import { Rocket, Users, Lightbulb, AlertTriangle, ArrowRight } from 'lucide-react';

interface WelcomeScreenProps {
  onContinue: () => void;
}

const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onContinue }) => {
  return (
    <div className="fixed inset-0 bg-gray-950 z-50 flex items-center justify-center p-3">
      <div className="max-w-lg w-full bg-gray-900 rounded-xl border border-gray-700 overflow-hidden max-h-[95vh]">
        {/* Compact Header */}
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-4 text-center">
          <div className="flex items-center justify-center space-x-2 mb-2">
            <Rocket className="h-6 w-6 text-white" />
            <h1 className="text-lg font-bold text-white">Welcome to Netic</h1>
          </div>
          <p className="text-blue-100 text-sm">
            Where Your Ideas Become Reality! 🚀
          </p>
        </div>

        {/* Optimized Content */}
        <div className="p-4">
          <div className="mb-4">
            <p className="text-gray-300 text-sm leading-relaxed mb-3">
              This is our <strong className="text-white">MVP stage</strong>. We transform compelling community ideas into actual products.
            </p>
          </div>

          {/* Compact Feature List */}
          <div className="space-y-2 mb-4">
            <div className="flex items-start space-x-2">
              <div className="w-5 h-5 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <Lightbulb className="h-2.5 w-2.5 text-white" />
              </div>
              <div>
                <p className="text-white font-medium text-xs">Your ideas matter</p>
                <p className="text-gray-400 text-xs">Submit concepts you want to see built</p>
              </div>
            </div>

            <div className="flex items-start space-x-2">
              <div className="w-5 h-5 bg-purple-600 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <Users className="h-2.5 w-2.5 text-white" />
              </div>
              <div>
                <p className="text-white font-medium text-xs">Community-driven</p>
                <p className="text-gray-400 text-xs">Popular ideas get selected for development</p>
              </div>
            </div>

            <div className="flex items-start space-x-2">
              <div className="w-5 h-5 bg-green-600 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <Rocket className="h-2.5 w-2.5 text-white" />
              </div>
              <div>
                <p className="text-white font-medium text-xs">Beta phase coming</p>
                <p className="text-gray-400 text-xs">We'll build selected ideas into real products</p>
              </div>
            </div>
          </div>

          {/* Compact Call to Action */}
          <div className="bg-gray-800 rounded-lg p-3 border border-gray-700 mb-3">
            <p className="text-gray-300 text-center text-xs">
              Help us grow by sharing Netic with others!
            </p>
          </div>

          {/* Compact Warning */}
          <div className="bg-orange-900/20 border border-orange-600/30 rounded-lg p-2 mb-4">
            <div className="flex items-start space-x-2">
              <AlertTriangle className="h-3 w-3 text-orange-400 flex-shrink-0 mt-0.5" />
              <p className="text-orange-200 text-xs">
                <strong>Only submit ideas you're comfortable with us developing.</strong>
              </p>
            </div>
          </div>

          {/* Compact Continue Button */}
          <button
            onClick={onContinue}
            className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold py-2 px-4 rounded-lg transition-all duration-200 flex items-center justify-center space-x-2 group text-xs"
          >
            <span>Click anywhere to continue</span>
            <ArrowRight className="h-3 w-3 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default WelcomeScreen;